#include <Arduino.h>
// #include "motor_control.h"
#include "motor_control.h"
#include "Path_function2.h"

void setup()
{

  Serial.begin(115200);
  motorSetup(10000, 2500); // 2500 คือ 2500 step/s ยกกำลัง 2
  //*******************************GRIP USE grip(25)**********************/
  //*******************************UNGRIP USE grip(160)**********************/
  Rotate(102);
  delay(1000);
  Gripped(160);
  delay(1000);
  homePosition();








  // moveTomm(4.8, 120, 0);
  // moveTomm(4.8, 120, 86);
  // Rotate(9);
}

void loop()
{
   receiveSerialCommand();
}